![image](https://user-images.githubusercontent.com/79082037/222970367-4147409b-0be8-481d-b8c3-ebf9e16d1d6e.png)
# Lone Wolf Games
Project 1 for the Game Design and Development subject of CITM UPC
Altered Beast is a 1988 beat'em up arcade video game developed and manufactured by Sega. The game is set in Ancient Greece and follows a player character chosen by Zeus to rescue his daughter Athena from the demonic ruler of the underworld, Neff. Through the use of power-ups, the player character can assume the form of different magical beasts (wolf, dragon, bear, tiger, and golden wolf). It was ported to several home video game consoles and home computers. It was the pack-in game for the Sega Mega Drive when that system launched in 1988



Team Members
Everything

Ogylandy Yespagambetov - [Oga29](https://github.com/Oga29) github.com/Oga29

Control:
W - Jump
A - Left
D - Right
Space - Ability

F1 - Debug
F2 - GodMode
F3 - Start Again
F4 - GameOver


[Youtube Video](https://youtu.be/yFXSDuM7CQg)


[Lone-Wolf Games](https://github.com/Oga29/Lone-Wolf-Game)


https://github.com/Oga29/Lone-Wolf-Game
